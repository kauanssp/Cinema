using CinemaApp.Cadastros;
using CinemaApp.Infra;
using Microsoft.Extensions.DependencyInjection;
using ReaLTaiizor.Forms;

namespace CinemaApp
{
    public partial class FormPrincipal : MaterialForm
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void ExibeFormulario<TFormulario>() where TFormulario : Form
        {
            var cad = ConfigureDI.ServiceProvider!.GetService<TFormulario>();
            if (cad != null && !cad.IsDisposed)
            {
                cad.MdiParent = this;
                cad.Show();
            }
            else
            {
                MessageBox.Show($"Não foi possível abrir o formulário {typeof(TFormulario).Name}.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void generoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibeFormulario<CadastroGenero>();
        }

        private void filmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibeFormulario<CadastroFilme>();
        }

        private void sessãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibeFormulario<CadastroSessao>();
        }

        private void salaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExibeFormulario<CadastroSala>();
        }
    }
}

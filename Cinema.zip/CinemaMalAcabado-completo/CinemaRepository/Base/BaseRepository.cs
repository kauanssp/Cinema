﻿using CinemaDomain.Base;
using CinemaRepository.Context;
using Microsoft.EntityFrameworkCore;

namespace CinemaRepository.Base
{
    public class BaseRepository<TypeEntity> : IBaseRepository<TypeEntity> where TypeEntity : BaseEntity
    {
        protected readonly MyDBContext _myDBContext;

        public BaseRepository(MyDBContext myDBContext)
        {
            _myDBContext = myDBContext;
            _myDBContext.Set<TypeEntity>();
        }

        public void Create(TypeEntity entity)
        {
            _myDBContext.Add(entity);
            _myDBContext.SaveChanges();
        }

        public TypeEntity ReadById(int id)
        {
            var dbContext = _myDBContext.Set<TypeEntity>().AsQueryable();
            return dbContext.ToList().Find(x => x.Id == id);
        }

        public IList<TypeEntity> ReadAll()
        {
            var dbContext = _myDBContext.Set<TypeEntity>().AsQueryable();
            return dbContext.ToList();
        }

        public void Update(TypeEntity entity)
        {
            var localEntity = _myDBContext.Set<TypeEntity>()
                .Local
                .FirstOrDefault(existingEntity => existingEntity.Id == entity.Id);

            if (localEntity is not null)
            {
                _myDBContext.Entry(localEntity).CurrentValues.SetValues(entity);
                _myDBContext.Entry(localEntity).State = EntityState.Modified;
            }
            else
            {
                _myDBContext.Entry(entity).State = EntityState.Modified;
            }

            _myDBContext.SaveChanges();
        }

        public void Delete(int id)
        {
            _myDBContext.Remove(ReadById(id));
            _myDBContext.SaveChanges();
        }
    }
}
